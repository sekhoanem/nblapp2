<?php
header('Content-type: text/json');
echo '[';
$separator = "";
$days = 16;
 

$i = 1;
    echo $separator;
    $initTime = date("Y")."-".date("m")."-".date("d")." ".date("H").":00:00";
    //$initTime = date("Y-m-d H:i:00");
    echo '  { "date": "2016-09-10 9:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-10 11:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-10 13:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-10 15:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-10 17:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-11 12:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-11 14:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-11 16:00:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-14 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-16 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-17 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-17 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-17 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-17 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-17 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-18 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-18 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-18 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	
	echo '  { "date": "2016-09-21 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-21 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-21 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-21 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
	echo '  { "date": "2016-09-21 17:30:00", "type": "meeting", "title": "L - KTA vs BBH", "description": "Lehakoe", "url": "#" },';
    
    echo '  { "date": "'; echo date("Y-m-d H:i:00",strtotime($initTime. ' - 208 days 1 hours')); echo '", "type": "test", "title": "A very very long name for a f*cking project '; echo $i; echo ' events", "description": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam.", "url": "http://www.event11.com/" }';
    $separator = ",";

echo ']';
?>